package com.spring.formTag.model;

import java.util.LinkedHashMap;

public class Student {
	private String firstName;
	private String lastName;
	private String course;
	private String favoriteLanguage;
	private String checkBox;
	private String hobb;
	
	private LinkedHashMap<String, String> courses;
	private LinkedHashMap<String, String> favoriteLanguages;
	
	
	
	public Student() {
		courses = new LinkedHashMap<String, String>();
		courses.put("C", "C");
		courses.put("C++", "C++");
		courses.put("Java", "Java");
		courses.put("Python", "Python");
		courses.put("Spring", "Spring");
		favoriteLanguages = new LinkedHashMap<String, String>();
		favoriteLanguages.put("C", "C");
		favoriteLanguages.put("C++", "C++");
		favoriteLanguages.put("Java", "Java");
		favoriteLanguages.put("Python", "Python");
		favoriteLanguages.put("HTML", "HTML");
	}
	public LinkedHashMap<String, String> getCourses() {
		return courses;
	}
	
	
	public LinkedHashMap<String, String> getFavoriteLanguages() {
		return favoriteLanguages;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	
	public String getFavoriteLanguage() {
		return favoriteLanguage;
	}
	public void setFavoriteLanguage(String favoriteLanguage) {
		this.favoriteLanguage = favoriteLanguage;
	}
	public String getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(String checkBox) {
		this.checkBox = checkBox;
	}
	public String getHobb() {
		return hobb;
	}
	public void setHobb(String hobb) {
		this.hobb = hobb;
	}
	
}
