package com.spring.formTag;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.formTag.model.Student;

@Controller
@RequestMapping("/student")
public class StudentController {
	@RequestMapping("/showForm")
	public String showForm(Model model) {
	//Create a new Student Object
	Student student = new Student();
	//Add student object to model
	model.addAttribute("student", student);
	return "student-form";
	}
	
	@RequestMapping("/processForm")
	public String processDataForm(@ModelAttribute("student") Student student) {
		return "student-confirmation";
	}
}
